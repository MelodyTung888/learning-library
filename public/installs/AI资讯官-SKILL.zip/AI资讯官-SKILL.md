---
name: ai-daily-news-v2
description: >
  AI 每日新闻简报生成器。从 smol.ai RSS、主流科技媒体（VentureBeat AI、TechCrunch AI、The Verge AI）抓取内容，
  按 5 大类别（重大发布/研究论文/行业商业/工具应用/政策安全）整理，输出结构化 Markdown 报告。
  支持 Brief/Standard/Deep 三种详细程度，以及按时间/公司/类别的不同组织形式。
  触发词：AI资讯、每日AI新闻、AI日报、昨天AI资讯、AI动态、AI今日新闻、daily AI news、AI briefing
---

# AI Daily News Briefing

AI 每日新闻简报生成器。从多个来源聚合、筛选、分类 AI 行业资讯，输出可直接阅读的结构化报告。

## 核心工作流（4 阶段）

```
Phase 1: 信息采集
  ├─ smol.ai RSS（https://news.smol.ai/rss.xml）
  └─ 主流媒体抓取（VentureBeat / TechCrunch / The Verge）
      ↓
Phase 2: 内容过滤
  ├─ 保留：最近48小时，重大发布/研究报告/融资并购
  └─ 剔除：重复内容/营销软文/过时资讯
      ↓
Phase 3: 五大分类
  ├─ 🔥 重大发布（模型发布、产品发布）
  ├─ 🔬 研究论文（学术突破、开源模型）
  ├─ 💼 行业商业（融资、并购、合作）
  ├─ 🛠️ 工具应用（AI工具、框架、开源）
  └─ 🌍 政策安全（监管、隐私、安全事件）
      ↓
Phase 4: 输出格式化
  └─ Markdown 报告 + 链接 + 要点提炼
```

## 信息采集（Phase 1）

### 首选 RSS 源
- **smol.ai**：`https://news.smol.ai/rss.xml`（最全的 AI 工程师日报，覆盖 Twitter/Reddit/Discord）
- 直接抓取 RSS XML 内容，提取 item 节点中的 description/link/pubDate

### 辅助新闻源（任选 2-3 个）
- VentureBeat AI：`https://venturebeat.com/category/ai/`
- TechCrunch AI：`https://techcrunch.com/category/artificial-intelligence/`
- The Verge AI：`https://www.theverge.com/ai-artificial-intelligence`
- AI News：`https://artificialintelligence-news.com/`
- 36氪 RSS：`https://36kr.com/feed`

### 采集命令
```bash
# smol.ai RSS（首选，最全）
web_fetch --url "https://news.smol.ai/rss.xml" --extractMode markdown --maxChars 15000

# TechCrunch AI RSS
web_fetch --url "https://techcrunch.com/category/artificial-intelligence/feed/" --extractMode markdown --maxChars 15000

# VentureBeat
web_fetch --url "https://venturebeat.com/category/ai/" --extractMode markdown --maxChars 5000
```

## 内容过滤（Phase 2）

### 保留标准
- 最近 48 小时内发布的内容
- 重大宣布（模型发布、产品发布）
- 行业动态（融资、并购、合作）
- 技术突破（开源模型、新研究）
- 主要公司更新（OpenAI、Google、Anthropic、Meta、Microsoft）

### 剔除标准
- 重复报道（保留最权威来源）
- 营销软文（无实质技术内容）
- 超过 3 天的内容（除非极其重要）
- 非 AI 相关内容

## 五大分类（Phase 3）

### 🔥 重大发布
- 模型发布（GPT、Claude、Gemini、LLaMA 等）
- 产品发布（AI 工具、服务、功能更新）
- 主要公司重要宣布

### 🔬 研究与论文
- 学术突破
- 新论文（arXiv 等）
- 新技术或新方法论
- Benchmark 成就

### 💼 行业与商业
- 融资轮次和投资
- 并购
- 合作与战略协议
- 市场趋势分析

### 🛠️ 工具与应用
- 新 AI 工具和框架
- 实际 AI 应用案例
- 开源项目发布
- 开发者资源

### 🌍 政策与安全
- AI 法规和政策
- 安全和伦理讨论
- 社会影响研究
- 政府举措

## 输出格式（Phase 4）

详见 references/output_templates.md，默认使用 **Standard 格式**。

### 格式选择指引

| 格式 | 适用场景 | 长度 |
|------|----------|------|
| **Brief** | 快速浏览、时间紧张 | 短 |
| **Standard** | 每日简报（默认） | 中 |
| **Deep** | 深度分析、研究 | 长 |

### 时间范围
- 最近 24 小时（默认）
- 最近 3 天
- 最近 7 天
- 自定义范围

### 组织方式
- 按类别（默认）
- 按时间顺序
- 按公司
- 按显著性

## 使用示例

### 基础用法
```
用户：昨天AI资讯
执行：Phase1 → Phase2 → Phase3 → Phase4（Standard格式）
```

### 带选项
```
用户：昨天的AI研究进展，要Deep格式
执行：Phase1 → Phase2（仅研究类）→ Phase3 → Phase4（Deep格式）
```

### 深度研究
```
用户：关于 Claude Code 泄露的详细报道
执行：fetch full article → 详细摘要 → 分析影响
```

## 参考文件

- references/output_templates.md — 输出格式模板（含 Brief/Standard/Deep/Chronological/By-Company）
- references/news_sources.md — 新闻源完整列表（Tier 1-4）
- references/search_queries.md — 搜索查询模板
